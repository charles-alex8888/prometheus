#/bin/bash

wget https://github.com/prometheus/node_exporter/releases/download/v1.0.1/node_exporter-1.0.1.linux-amd64.tar.gz
tar xf node_exporter-1.0.1.linux-amd64.tar.gz -C /usr/local/src/
ln -s /usr/local/src/node_exporter-1.0.1.linux-amd64 /usr/local/node_exporter

cat >/usr/lib/systemd/system/node-exporter.service <<EOF
[Unit]
Description=Prometheus Server
After=network.target
[Service]
ExecStart=/usr/local/node_exporter/node_exporter
[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload && systemctl enable node-exporter.service && systemctl start node-exporter.service 


